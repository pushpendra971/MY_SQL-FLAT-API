const module_import     =require("./helper/module_import");
const mysql_config      =module_import.mysql_conf;
const response = module_import.response;
  const ajv = module_import.ajv;
  const validate_all = module_import.validate_all;


var mysql               = require('mysql'); 

let mysql_connection = mysql.createConnection(mysql_config);
 
let GET_SCHEMA = {
  "$async": true,
  "type": "object",
  "additionalProperties": true,
  "properties": {
    "FLAT_ID":{
      "TYPE":"NUMBER",
    },
    "BUILDING_ID":{
      "TYPE":"NUMBER"
    },
    "FLOOR_NO":{
      "TYPE":"NUMBER"
    },
    "FLAT_TYPE":{
      "TYPE":"STRING",
      "ENUM":["1-BHK","2-BHK","3-BHK","4-BHK"]
    },
    "FLAT_STATUS":{
      "TYPE":"STRING",
      "ENUM":["AVAILABLE","RESERVED","SOLD"]
    },
    "PRICE_PER_SQURE":{
      "TYPE":"FLOAT"
    },
    "FLAT_AREA":{
      "TYPE":"FLOAT",
    },
    "TOTAL_PRICE":{
      "TYPE":"STRING",
      "ENUM":["TRUE","FALSE"]
    },

    "FEATURE_NAME":{
      "TYPE":"STRING"
    },
  }
};

var validate = ajv.compile(GET_SCHEMA);
 
// execute the UPDATE statement

function execute(body,headers,callback){
  
console.log(body);
if(typeof(body)=="string"){
  body=JSON.parse(body);
}
console.log(body);
validate_all(validate, body)
    .then(function (result) {
        return uprec(result);
    })
    .then(function (result) {
        response({ code: 200, body: result }, callback);
    })
    .catch(function (err) {
        console.log(err);
        response({ code: 400, err: { err } }, callback);
    });
}


function uprec(body){
var mysql_query = " UPDATE FLAT SET ";
if(body!=null){
  //UPDATE FLAT STATUS AND TOTAL PRICE
  if(body.FLAT_STATUS){
      mysql_query += "FLAT_STATUS = '" + body.FLAT_STATUS +"'"; 
  }
  if(body.TOTAL_PRICE){
    mysql_query += ",TOTAL_PRICE = " + body.TOTAL_PRICE;
  }
  if(body.FLAT_ID){
      mysql_query += " WHERE FLAT_ID  = "+ body.FLAT_ID;
    }  
  }
console.log(mysql_query);

return new Promise((resolve, reject) => {
  mysql_connection.query(mysql_query, body,(error, results) => {
      if (error) {
          reject(error);
      }
      else {
          console.log(results);
          mysql_connection.end();
          resolve(results);
      }
  });
})

}
module.exports={execute};
