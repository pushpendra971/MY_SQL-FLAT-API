// const ajv = module_import.ajv;
//     const validate_all = module_import.validate_all;


    
    
//     var validate = ajv.compile(GET_SCHEMA);
//     function valid_execute(path,query,callback)
//         validate_all(validate,query)
//         .then(function(result){
//           if(result.id){
//             return GET_FLAT(result);
//           }else{
//             return Query_execute(result);
//           }
//         })
//         .then(function(result){
//             response({code:200,body:result},callback);
//         })
//         .catch(function(err){
//             console.log(err);
//             response({code:400,err:{err}},callback);
//         });
      
