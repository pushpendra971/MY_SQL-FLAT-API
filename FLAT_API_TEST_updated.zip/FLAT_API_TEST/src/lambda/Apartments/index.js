/** lambda execution start */
 try{     
var GET    =require("./GET");
var PUT    =require("./PUT");
var DELETE =require("./DELETE");
var POST   =require("./POST");
var DUMP   =require('./DUMP');
 }catch(e){console.log(e)};
exports.handler= function(event,context,callback){
   
    console.log(event);
    switch(event.httpMethod){
        case 'GET': GET.execute(event.pathParameters,event.queryStringParameters,callback);
                break;
        case 'PUT': PUT.execute(event.body,event.headers,callback);
                break;
        case 'DELETE': DELETE.execute(event.body,callback);
                break;    
        case 'POST': POST.execute(event.body,callback);
                break;     
        default: DUMP.execute(callback);
                break;
    }
}