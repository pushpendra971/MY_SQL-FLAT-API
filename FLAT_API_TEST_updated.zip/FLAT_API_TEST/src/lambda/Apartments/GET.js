const module_import     =require("./helper/module_import");
const validate_all = module_import.validate_all;
const response = module_import.response;
const ajv = module_import.ajv;

const mysql_config      =module_import.mysql_conf;

var mysql               = require('mysql'); 
var mysql_connection;
if(typeof(mysql_connection)=="undefined"){
  var mysql_connection = mysql.createConnection({
      host     : mysql_config.host,
      user     : mysql_config.user,
      password : mysql_config.password,
      database : mysql_config.database
    });
  }

let GET_SCHEMA = {
  "$async": true,
  "type": "object",
  "additionalProperties": false,
  "properties": {
    "FLAT_ID":{
      "TYPE":"NUMBER",
      "minimum":1,
      "maximum":1
    },
    "BUILDING_ID":{
      "TYPE":"NUMBER"
    },
    "FLOOR_NO":{
      "TYPE":"NUMBER"
    },
    "FLAT_TYPE":{
      "TYPE":"STRING",
      "ENUM":["1-BHK","2-BHK","3-BHK","4-BHK"]
    },
    "FLAT_STATUS":{
      "TYPE":"STRING",
      "ENUM":["AVAILABLE","RESERVED","SOLD"]
    },
    "PRICE_PER_SQURE":{
      "TYPE":"FLOAT"
    },
    "FLAT_AREA":{
      "TYPE":"FLOAT",
    },
    "TOTAL_PRICE":{
      "TYPE":"STRING",
      "ENUM":["TRUE","FALSE"]
    },

    "FEATURE_NAME":{
      "TYPE":"STRING"
    },

    "limit":{
      "TYPE":"STRING"
    }
  }
};

var validate = ajv.compile(GET_SCHEMA);
function execute(path,query, callback) {
  console.log(query);
  validate_all(validate,query)
      .then(function (result) {
          return execqry(result);
      })
      .then(function (result) {
          response({ code: 200, body: result }, callback);
      })
      .catch(function (err) {
          console.log(err);
          response({ code: 400, err: { err } }, callback);
      });
}


function execqry(query){

  console.log(query);

  var mysql_query = " SELECT FLAT.* ";
  
  if(query!= null){
    if(query.FEATURE_NAME && query.FLAT_TYPE && query.FLAT_STATUS && query.FLOOR_NO && query.BUILDING_ID){
      mysql_query += " ,FEATURES.* FROM ((FLAT INNER JOIN FLAT_FEATURES ON FLAT.FLAT_ID=FLAT_FEATURES.FLAT_ID) INNER JOIN FEATURES ON FLAT_FEATURES.FEATURE_ID=FEATURES.FEATURE_ID) WHERE FEATURES.FEATURE_NAME = "+query.FEATURE_NAME;
      if(query.TOTAL_PRICE=="TRUE"){
        mysql_query+= "order by TOTAL_PRICE";
      }else {
        mysql_query+= "order by TOTAL_PRICE DESC"; 
      }
      
      if(query.limit){
          mysql_query+= " limit "+query.limit;
    }
  } 
    else if(query.FLAT_TYPE && query.FLAT_STATUS && query.FLOOR_NO && query.TOTAL_PRICE && query.BUILDING_ID){
     if(query.FLAT_TYPE || query.FLOOR_NO){
      mysql_query += " FROM FLAT WHERE ";
      }
      WHERE = [];
      COUNT = 0;
      if(query.FLAT_TYPE){
          WHERE[COUNT] = " (FLAT_TYPE = " + query.FLAT_TYPE;
          COUNT++;
      }
      if(query.FLOOR_NO){
          WHERE[COUNT] = " FLOOR_NO  = " + query.FLOOR_NO + ")";
          COUNT++;
      }
      mysql_query += WHERE.join(" AND ");
      mysql_query += " OR ";
      WHERE1 = [];
      COUNT1=0;
      if(query.BUILDING_ID){
          WHERE1[COUNT1] = "( BUILDING_ID = " + query.BUILDING_ID;
          COUNT1++;
      }
      if(query.FLAT_STATUS){
          WHERE1[COUNT1] = " FLAT_STATUS = " + query.FLAT_STATUS+ ")";
          COUNT1++;
      }
      mysql_query += WHERE1.join(" AND ");
      if(query.TOTAL_PRICE=="TRUE"){
        mysql_query+= "order by TOTAL_PRICE";
      }else {
        mysql_query+= "order by TOTAL_PRICE DESC"; 
      }
     if(query.limit){
      mysql_query+= " limit "+query.limit;
    } 
    }else if(query.FEATURE_NAME){
         mysql_query += " ,FEATURES.* FROM ((FLAT INNER JOIN FLAT_FEATURES ON FLAT.FLAT_ID=FLAT_FEATURES.FLAT_ID) INNER JOIN FEATURES ON FLAT_FEATURES.FEATURE_ID=FEATURES.FEATURE_ID) WHERE FEATURES.FEATURE_NAME = "+query.FEATURE_NAME;
         if(query.limit){
          mysql_query+= " limit "+query.limit;
        }
    } else if(query.FLAT_STATUS && query.FLAT_TYPE && query.FLOOR_NO){
        mysql_query+=" FROM FLAT WHERE FLAT_STATUS = "+query.FLAT_STATUS +" AND FLAT_TYPE= "+query.FLAT_TYPE+" AND FLOOR_NO= "+query.FLOOR_NO;
        if(query.limit){
          mysql_query+= " limit "+query.limit;
        }
      }else if(query.BUILDING_ID && query.FLAT_TYPE){
        mysql_query+=" FROM FLAT WHERE BUILDING_ID = "+query.BUILDING_ID +" AND FLAT_TYPE= "+query.FLAT_TYPE;
        if(query.limit){
          mysql_query+= " limit "+query.limit;
        }
      }else if(query.BUILDING_ID && query.FLOOR_NO){
        mysql_query+=" FROM FLAT WHERE BUILDING_ID = "+query.BUILDING_ID +" AND FLOOR_NO= "+query.FLOOR_NO;
        if(query.limit){
          mysql_query+= " limit "+query.limit;
        }
      }else if(query.FLAT_STATUS && query.BUILDING_ID){
        mysql_query+=" FROM FLAT WHERE FLAT_STATUS = "+query.FLAT_STATUS +" AND BUILDING_ID= "+query.BUILDING_ID;
        if(query.limit){
          mysql_query+= " limit "+query.limit;
        }
      }else if(query.FLAT_STATUS && query.FLAT_TYPE){
          mysql_query+=" FROM FLAT WHERE FLAT_STATUS = "+query.FLAT_STATUS +" AND FLAT_TYPE= "+query.FLAT_TYPE;
          if(query.limit){
            mysql_query+= " limit "+query.limit;
          }
        }else if(query.FLAT_STATUS && query.FLOOR_NO){
          mysql_query+=" FROM FLAT WHERE FLAT_STATUS = "+query.FLAT_STATUS +" AND FLOOR_NO= "+query.FLOOR_NO;
          if(query.limit){
            mysql_query+= " limit "+query.limit;
          }
        }else if(query.FLAT_TYPE && query.FLOOR_NO){
          mysql_query+=" FROM FLAT WHERE FLAT_TYPE = "+query.FLAT_TYPE +" AND FLOOR_NO= "+query.FLOOR_NO;
          if(query.limit){
            mysql_query+= " limit "+query.limit;
          }
        }else if(query.BUILDING_ID){
        mysql_query+=" FROM FLAT WHERE BUILDING_ID = "+query.BUILDING_ID;
        if(query.limit){
          mysql_query+= " limit "+query.limit;
        } 
      }else if(query.FLAT_TYPE){
        mysql_query+=" FROM FLAT WHERE FLAT_TYPE = "+query.FLAT_TYPE;
        if(query.limit){
          mysql_query+= " limit "+query.limit;
        } 
      }else if(query.FLAT_STATUS){
        mysql_query+=" FROM FLAT WHERE FLAT_STATUS = "+query.FLAT_STATUS;
        if(query.limit){
          mysql_query+= " limit "+query.limit;
        } 
      }else if(query.FLOOR_NO){
        mysql_query+=" FROM FLAT WHERE FLOOR_NO = "+query.FLOOR_NO;
        if(query.limit){
          mysql_query+= " limit "+query.limit;
        } 
      }    
  }

  console.log(mysql_query);


  return new Promise((resolve, reject) => {
    mysql_connection.query(mysql_query, query,(error, results) => {
        if (error) {
            reject(error);
        }
        else {
            console.log(results);
            mysql_connection.end();
            resolve(results);
        }
    });
})
}
module.exports={execute};
