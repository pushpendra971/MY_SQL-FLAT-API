//try{
  const module_import = require('./helper/module_import');
  const mysql_config = module_import.mysql_conf;
  const response = module_import.response;
  const ajv = module_import.ajv;
  const validate_all = module_import.validate_all;
  // } catch(e){console.log(e);}
  var mysql = require('mysql');
  var mysql_connection;
  if (typeof (mysql_connection) == "undefined") {
      mysql_connection = mysql.createConnection({
          host: mysql_config.host,
          user: mysql_config.user,
          password: mysql_config.password,
          database: mysql_config.database
      });
  }
  
  let GET_SCHEMA = {
      "$async": true,
      "type": "object",
      "additionalProperties": false,
      "properties": {
          "required":true,
          "FLAT_ID": {
              "type": "string"
          }
      }
  };
  
  var validate = ajv.compile(GET_SCHEMA);
  
  /**
   * Start execution
   */
  function execute(body,callback) {
      if(typeof(body)=="string")
     {
        var body = JSON.parse(body);
     }
  
      console.log(body);
      validate_all(validate, body)
          .then(function (result) {
              return remove(result);
          })
          .then(function (result) {
              response({ code: 200, body: result }, callback);
          })
          .catch(function (err) {
              console.log(err);
              response({ code: 400, err: { err } }, callback);
          });
  }
  
  function remove(body) {
      if (typeof (mysql_connection) == "undefined") {
          mysql_connection = mysql.createConnection({
              host: mysql_config.host,
              user: mysql_config.user,
              password: mysql_config.password,
              database: mysql_config.database
          });
      }
  
      if(typeof(body)=="string")
     {
        let body = JSON.parse(body);
     }
      console.log(body);
      var mysql_query = "";
  
      if (body != null) {
          var mysql_query = "DELETE FROM FLAT WHERE FLAT_ID = '" + parseInt(body.FLAT_ID) + "';";
      }
  
      console.log(mysql_query);
  
      return new Promise((resolve, reject) => {
          mysql_connection.query(mysql_query, body,(error, results) => {
              if (error) {
                  reject(error);
              }
              else {
                  console.log(results);
                  mysql_connection.end();
                  resolve(results);
              }
          });
      })
  }
  
  module.exports = { execute };