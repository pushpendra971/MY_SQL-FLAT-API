// try{
const module_import     =require("./helper/module_import");
const mysql_config      =module_import.mysql_conf;
const response = module_import.response;
  const ajv = module_import.ajv;
  const validate_all = module_import.validate_all;
// } catch(e){console.log(e);}

var mysql               = require('mysql'); 

let mysql_connection = mysql.createConnection(mysql_config);
 
let GET_SCHEMA = {
  "$async": true,
  "type": "object",
  "additionalProperties": true,
  "properties": {
    "FLAT_ID":{
      "TYPE":"NUMBER",
    },
    "BUILDING_ID":{
      "TYPE":"NUMBER"
    },
    "FLOOR_NO":{
      "TYPE":"STRING"
    },
    "FLAT_TYPE":{
      "TYPE":"STRING",
      "ENUM":["1-BHK","2-BHK","3-BHK","4-BHK"]
    },
    "FLAT_STATUS":{
      "TYPE":"STRING",
      "ENUM":["AVAILABLE","RESERVED","SOLD"]
    },
    "PRICE_PER_SQURE":{
      "TYPE":"FLOAT"
    },
    "FLAT_AREA":{
      "TYPE":"FLOAT",
    },
    "TOTAL_PRICE":{
      "TYPE":"STRING"
   
    },

    "FEATURE_NAME":{
      "TYPE":"STRING"
    },
  }
};

var validate = ajv.compile(GET_SCHEMA);
 
// execute the add record statement

function execute(body,callback){
  
console.log(body);
if(typeof(body)=="string"){
  body=JSON.parse(body);
}
console.log(body);
validate_all(validate, body)
    .then(function (result) {
        return addrec(result);
    })
    .then(function (result) {
        response({ code: 200, body: result }, callback);
    })
    .catch(function (err) {
        console.log(err);

        response({ code: 400, err: { err } }, callback);
    });
}


function addrec(body){
var mysql_query = " INSERT INTO FLAT (FLAT_ID,BUILDING_ID,FLOOR_NO,FLAT_TYPE,FLAT_STATUS,FLAT_AREA,PRICE_PER_SQURE,TOTAL_PRICE) VALUES( ";
if(body!=null){
  
   mysql_query += body.FLAT_ID + " , " +body.BUILDING_ID+" , " + body.FLOOR_NO +" , '" + body.FLAT_TYPE +"' , '"+ body.FLAT_STATUS+ "' , "+body.FLAT_AREA +" , "+body.PRICE_PER_SQURE+" , "+body.TOTAL_PRICE+ " )"; 
    
}  
console.log(mysql_query);

return new Promise((resolve, reject) => {
  mysql_connection.query(mysql_query, body,(error, results) => {
      if (error) {
          reject(error);
      }
      else {
          console.log(results);
          mysql_connection.end();
          resolve(results);
      }
  });
})

}
module.exports={execute};
