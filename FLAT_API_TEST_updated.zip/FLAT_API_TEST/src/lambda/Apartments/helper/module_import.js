/**
 * Import npm modules used on the system
 */
const AWS 					= require('aws-sdk');
const Ajv 	     			= require('ajv');
const setupAsync 			= require('ajv-async');
const ajv 		 			= setupAsync(new Ajv());
const jwt                   = require('jsonwebtoken');

if(process.env.AWS_REGION == "local"){
	mode 		            = "offline";
	// sns 		            = require('../../../../offline/sns');
	docClient 	            = require('../../../../offline/dynamodb').docClient;
	// neo4j			    = require('../../../../offline/Neo4j');
	S3 			            = require('../../../../offline/S3');
	// dynamodb             = require('../../../../offline/dynamodb').dynamodb;
	 mysql_conf           = require('../../../../offline/mysql').Mysql["dev-conf"];
}else{
	mode 		            = "online";
	// sns 		            = new AWS.SNS();
	docClient 	            = new AWS.DynamoDB.DocumentClient({});
	S3 			            = new AWS.S3();
	// neo4j 		        = require('./lib/neo4j');
	// dynamodb             = new AWS.DynamoDB();
	mysql_conf           = database.Mysql["prod-conf"];
}

/**
 * Import custom modules used on the system
 */
const authorization         = require('./authorization')(jwt);
const validate_all          = require('./validate');
const response              = require('./response');
const database              = require('./database');

module.exports ={
    ajv,
    docClient,
    S3,
    authorization,
    validate_all,
    response,
	database,
	mode,
	mysql_conf
};