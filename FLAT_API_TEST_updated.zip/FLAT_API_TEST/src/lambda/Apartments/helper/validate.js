
/**
 * validate the data based on the schema
 * @param  {[type]} data [description]
 * @return {[type]}      [description]
 */
function check (validate,data) {
	return new Promise((resolve,reject)=>{
		console.log("ans");
		console.log(validate);
		validate(data).then(function (res) {
			console.log(res);
		    resolve(res);
		}).catch(function(err){
		  console.log(JSON.stringify( err,null,6) );
		  reject(err.errors[0].dataPath+" "+err.errors[0].message);
		})
	})
}

module.exports = function(validate,data){
	return check(validate,data);
};