
/**
 * 
 * @param {*} token 
 * @param {*} result 
 */
function authorization(jwt,token,result) { //console.log(token)
	return new Promise ((resolve, reject)=>{
		var decode = jwt.decode(token)
		if(!decode){
			return reject('no authorization token provided')
		}else if(decode['cognito:username'] == undefined){
			return reject('cognito username not found in the token')
		}
		result['username'] = decode['email'];
		resolve(result)
	})  
}

module.exports = function(jwt){
		return function(token,result){
			return authorization(jwt,token,result);
		}
}