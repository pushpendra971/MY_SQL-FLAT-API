
// const uri = "bolt://192.168.0.19";
// const user = "neo4j";
// const password = "vinay";

// const neo4j = require('neo4j-driver').v1;

// const driver = neo4j.driver(uri, neo4j.auth.basic(user, password));
// const session = driver.session();

// module.exports = session;

/**production 
 * username neo4j
 * password qwertasdfg
 */
// const username = "neo4j";
// const uri = "18.194.45.177";
// const password = "qwertasdfg";


/**development */
var config  = require("./config");

const username = "neo4j";
const password = "vinay";
const uri 	= config.url;
const port = 7474;

var neo4j = require('neo4j');
var dbinstance = `http://${username}:${password}@${uri}:${port}`;
console.log(dbinstance);
var db = new neo4j.GraphDatabase(dbinstance);

module.exports = db;
