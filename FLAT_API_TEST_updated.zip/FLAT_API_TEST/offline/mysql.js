var config = require("./config");

module.exports={
	"Mysql":{
		"dev-conf":{
			"connectionLimit":10,
			"host":config.url,
			"user":"root",
			"password":"root",
			"database":"Apartments"
		}
	}
};