## Database setup
### Tables
1. List Of Jobs  
   ALL the database value will be inserted inside it.  
   configuration 
   
   ```
    (HASH)  listing: ID - (tech_backend)
    (RANGE) page: ID - (delhi,noida)
   ```
   ```
    {
        TableName: 'JOBS_LIST',
        KeySchema: [
            {
                AttributeName: 'listing',
                KeyType: 'HASH',
            },
            {
                AttributeName: 'page', 
                KeyType: 'RANGE', 
            }
        ],
        AttributeDefinitions: [
            {
                AttributeName: 'listing',
                AttributeType: 'S',
            },
            {
                AttributeName: 'page',
                AttributeType: 'S',
            }
        ],
        ProvisionedThroughput: { // required provisioned throughput for the table
            ReadCapacityUnits: 1, 
            WriteCapacityUnits: 1, 
        }
    };
   ```
   
2. User details  
    User will insert his/her data
    configuration
    ```
        (HASH) emailId
        (RANGE) approve
    ```
    ```
         {
            TableName: 'Applications',
            KeySchema: [
                {
                    AttributeName: 'email',
                    KeyType: 'HASH',
                },
                {
                    AttributeName: 'approve',
                    KeyType: 'RANGE',
                }
            ],
            AttributeDefinitions: [
                {
                    AttributeName: 'email',
                    AttributeType: 'S',
                },
                {
                    AttributeName: 'approve',
                    AttributeType: 'S',
                }
            ],
            ProvisionedThroughput: {
                ReadCapacityUnits: 1, 
                WriteCapacityUnits: 1, 
            }
        };
    ```
3. Tasks  
    Based on the Jobs there are multiple assesments task
    ```
        (HASH) Job
        (RANGE) active
    ```
    ```
     {
            TableName: 'JOBS_ASSESSMENT',
            KeySchema: [
                {
                    AttributeName: 'job',
                    KeyType: 'HASH',
                },
                {
                    AttributeName: 'active', 
                    KeyType: 'RANGE', 
                }
            ],
            AttributeDefinitions: [
                {
                    AttributeName: 'job',
                    AttributeType: 'S',
                },
                {
                    AttributeName: 'active',
                    AttributeType: 'S',
                }
            ],
            ProvisionedThroughput: {
                ReadCapacityUnits: 1, 
                WriteCapacityUnits: 1, 
            }
        };
    ```