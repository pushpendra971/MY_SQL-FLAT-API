#!/bin/bash

# 'Usage' sudo bash task.sh test arn:aws:iam::188097494660:role/LambdaAccesstoAWSService
projectname=$1
function_name=$(jq -r '.FunctionName' ../../src/configuration/newLambda.json)
role=$2
runtime1=$(jq -r '.Runtime' ../../src/configuration/newLambda.json)
description=$(jq -r '.Description' ../../src/configuration/newLambda.json)
timeout=$(jq '.Timeout' ../../src/configuration/newLambda.json)
MemorySize=$(jq '.MemorySize' ../../src/configuration/newLambda.json)
environment=$(jq -r '.environment' ../../src/configuration/newLambda.json)
tags=$(jq -r '.tags' ../../src/configuration/newLambda.json)

# echo $runtime1
# runtime=$(echo "${runtime1}")
# echo
# description="$description"
runtime=$runtime1
# runtime=$($runtime1 | sed "s/\"//g")
function_name=$projectname"_"$function_name
echo $function_name;

echo "aws lambda create-function --function-name $function_name --role $role --runtime $runtime --handler "index.handler" --timeout $timeout --memory-size $MemorySize --description $description --zip-file 'fileb://sample.zip' --tags $tags"
aws lambda create-function --function-name $function_name \
--role $role \
--runtime $runtime \
--handler "index.handler" \
--timeout $timeout \
--memory-size $MemorySize \
--description "$description" \
--zip-file 'fileb://sample.zip' \
--environment $environment \
--tags $tags
# --environment 'Variables={S3_BUCKET=Test}' \
# --tags 'Departement=asdd,Dp=2' \

## Now create ALias 3 (development,stage & production)

aws lambda create-alias --function-name $function_name --name development --function-version '$LATEST'
aws lambda create-alias --function-name $function_name --name stage --function-version '$LATEST'
aws lambda create-alias --function-name $function_name --name production --function-version '$LATEST'
